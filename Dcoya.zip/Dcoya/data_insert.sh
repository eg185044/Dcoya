#!/bin/bash

# Ask user's name and age
read -p "Enter your name: " name
read -p "Enter your age: " age

# Connect to MySQL container
mysql -h mysql -u appuser -papppassword appdb -e "INSERT INTO users (Name, Age) VALUES ('$name', $age)"
