#!/bin/bash

# Connect to MySQL container
mysql -h mysql -u appuser -papppassword appdb -e "SELECT * FROM users"
