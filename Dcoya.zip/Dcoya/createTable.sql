CREATE TABLE IF NOT EXISTS users (
  Name TEXT,
  Age INT
);
