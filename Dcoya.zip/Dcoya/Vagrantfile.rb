Vagrant.configure("2.2.14") do |config|
  config.vm.box = "ubuntu/lts"
  config.vm.provider "virtualbox" do |vb|
    vb.memory = "2048"
  end

  config.vm.network "private_network", ip: "192.168.56.10"

  config.vm.provision "docker" do |d|
    d.compose_file = "docker-compose.yml"
  end
end
